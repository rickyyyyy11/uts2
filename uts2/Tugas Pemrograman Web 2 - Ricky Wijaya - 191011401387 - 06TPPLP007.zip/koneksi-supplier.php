<?php

$servername = 'localhost';
$username   = 'root';
$password   = '';
$db_name    = 'db_uts_06tplp007_rickywijaya';

$conn = mysqli_connect($servername, $username, $password, $db_name);
?>